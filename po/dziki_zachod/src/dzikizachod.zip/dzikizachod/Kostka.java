package dzikizachod;

import java.util.Random;

class Kostka {
    static int rzut(Random rand) {
        return rand.nextInt(6) + 1;
    }
}
