package dzikizachod;

public enum Akcja {
    ULECZ,
    STRZEL,
    ZASIEG_PLUS_JEDEN,
    ZASIEG_PLUS_DWA,
    DYNAMIT
}
